<?php

namespace App\Http\Controllers;

use App\Models\Directorio;
use Illuminate\Http\Request;

class DirectorioController extends Controller
{
    public function index(){
        $directorios = Directorio::all();
        return view('directorios', compact('directorios'));
    }

    public function create(){
        return view('crearEntrada');
    }

    public function search(){
        return view('buscar');
    }
}
